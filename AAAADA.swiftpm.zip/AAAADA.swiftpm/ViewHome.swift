import SwiftUI

struct ViewHome: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let images = [
        "app1", "app2", "app3", "app4", "app5", "app6"
    ]
    
    let imageTexts = [
        "1. An App About Apps \nDette er et designprocesforløb der tager dig hele vejen fra at udvikle idéer, til at lave prototyper på apps, til i sidste ende at have lavet en færdig app. I denne infoknap får du et overblik over indholdet af appen.",
        "2. Tegn \nUnder fanen Tegn kan du anvende det indbyggede penalhus til at tegne og fortælle om dine idéer og udvikle layouts. Ved at klikke på idégenerering kan du tegne 8 appidéer, som du senere hen kan anvende til at udvælge den bedste idé. Under Blank, iPhone og iPad kan du tegne layouts til din app med forskellige typer af formater. ",
        "3. Freeform \nVed at klikke på Freeform får du muligheden for at downloade et Mindmap i Freeform, som kan bruges til at forbinde alle dine idéer knyttet til din app. I mindmappet vil du kunne trække forskellige typer af knapper, iPhone rammer og post-it sedler ind i dit arbejdsområde. Hvis du ønsker det, kan du også lave et traditionelt mindmap analogt på papir.",
        "4. Materialer \nUnder Materialer har du muligheden for at downloade materialer i Keynote hvor du kan udvikle prototyper til din app lige meget om appen er til Apple Watch, iPhone, iPad eller MacBook. Hvert et Keynote tema er unikt, med en række skabeloner til layouts til dine slides. Ydermere kan du også downloade lærermaterialer til projektet, samt aktiviteter til eleverne. Derudover, hvis du ønsker, kan du downloade lærermaterialer der knytter sig specifikt til kodning i Swift. ",
        "5. Apps \nUnder fanen Apps kan du lære hvordan du kan komme godt i gang med at kode med Swift. Du kan her få indsigt i Apples materialer Get Started Wit Kode og About Me. Unikt for An App About Apps har du muligheden for at downloade 4 apps, hvori du lærer at oprette Navigations Bars (menuer), Stacks Views (placering af objekter), Insert Content (tilføje tekst, billede, video og links) samt Things To Get You Started (en blanding af forskellige gode funktioner til din app)",
        "6. Portfolio \nI Portfolio kan du opdatere og dokumentere din rejse fra idé, layout, feedback, prototyper til færdig app. I Portfolio kan du uploade fotos fra din kamerarulle og med tekst beskrive din oplevelser. I bunden af Portfolio kan du tilføje flere billede- og tekstbokse"
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            GeometryReader { geometry in
                
                let imageSize = geometry.size.width / 10.65
                
                VStack(alignment: .center, spacing: 30) {
                    Text("An App About Apps")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(Color(red: 255 / 255, green: 150 / 255, blue: 141 / 255))
                        .padding(.top, 60)
                        .frame(maxWidth: 600)
                    
                    Image("LOGO")
                        .resizable()
                        .aspectRatio(2.4/1, contentMode: .fit)
                        .padding(.horizontal, imageSize)
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        .padding(-30)
                    
                    
                    Text("An App About Apps handler om gå fra at udvikle idéer til apps der er behov for, til at skitsere og beskrive idéer, lave prototyper af appen. Hvis du vil kan du også arbejde med at lære at kode i Swift, så du til sidste kan udgive en ægte app på App Store. Gør dine visioner og idéer til virkelighed!")
                        .font(.system(size: 20, weight: .regular)) 
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0)) 
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                    Text("Klik på informationsknappen for at få et overblik over appen.")
                        .font(.system(size: 20, weight: .regular)) 
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0)) 
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                    
                    
                }
                .padding(.bottom, 100)
                
                Spacer()
                
                    .padding()
                
                VStack {
                    Spacer()
                    
                    HStack {
                        Spacer()
                        
                        Button(action: {
                            showPopup.toggle()
                        }) {
                            Image(systemName: "info.circle")
                                .font(.largeTitle)
                                .padding()
                                .foregroundColor(.black)
                                .clipShape(Circle())
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 20)
                    }
                }
                
                if showPopup {
                    PopupView2(showPopup: $showPopup, images: images, imageTexts: imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                        .transition(.scale)
                        .zIndex(1)
                }
                
                if let index = fullscreenImageIndex {
                    FullScreenImageView(images: images, imageTexts: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                        .zIndex(2)
                }
            }
        }
    }
}
struct PopupView2: View {
    @Binding var showPopup: Bool
    let images: [String]
    let imageTexts: [String]
    @State private var currentPage: Int = 0
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Hvad er an app about apps?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        Image(images[index])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 400, height: 300)
                            .onTapGesture {
                                fullscreenImageIndex = index
                            }
                        
                        Text(imageTexts[index])
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, maxHeight: 200) 
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: 600, height: 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                showPopup = false
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: 600, height: 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
}
struct FullScreenImageView: View {
    let images: [String]
    let imageTexts: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                Spacer()
                
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        Image(images[index])
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .onTapGesture {
                                fullscreenImageIndex = nil
                            }
                            .padding()
                            .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                
                Text(imageTexts[currentIndex])
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                    )
                    .padding()
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                
                Text("\(currentIndex + 1) of \(images.count)")
                    .font(.footnote)
                    .padding(.bottom, 10)
                
                Spacer()
            }
        }
    }
}

struct ViewHome_Previews: PreviewProvider {
    static var previews: some View {
        ViewHome()
    }
}

